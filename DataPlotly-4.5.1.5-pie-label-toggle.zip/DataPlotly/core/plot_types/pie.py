"""
Pie chart factory

.. note:: This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
"""

import os
from plotly import graph_objs
from qgis.PyQt.QtGui import QIcon
from DataPlotly.core.plot_types.plot_type import PlotType


class PieChartFactory(PlotType):
    """
    Factory for pie charts
    """

    @staticmethod
    def type_name():
        return 'pie'

    @staticmethod
    def name():
        return PlotType.tr('Pie Chart')

    @staticmethod
    def icon():
        return QIcon(os.path.join(os.path.dirname(__file__), 'icons/pie.svg'))

    @staticmethod
    def create_trace(settings):
        """Creates a pie trace, including percentage label font controls."""
        font_family = settings.properties.get('pie_label_font_family', 'Arial')
        font_size = int(settings.properties.get('pie_label_font_size', 12))
        label_visible = bool(settings.properties.get('pie_label_visible', True))
        font_bold = bool(settings.properties.get('pie_label_font_bold', False))
        font_italic = bool(settings.properties.get('pie_label_font_italic', False))

        base_text_font = {
            'size': font_size,
            'family': font_family
        }
        styled_text_font = dict(base_text_font)
        styled_text_font['weight'] = 'bold' if font_bold else 'normal'
        styled_text_font['style'] = 'italic' if font_italic else 'normal'

        trace_arguments = {
            'labels': settings.x,
            'values': settings.y,
            'marker': {
                'colors': settings.data_defined_colors if settings.data_defined_colors else [settings.properties['in_color']]
            },
            'name': settings.properties['custom'][0],
            'hole': settings.properties.get('pie_hole', 0),
            'textinfo': 'percent' if label_visible else 'none',
            'textfont': styled_text_font
        }

        try:
            return [graph_objs.Pie(**trace_arguments)]
        except ValueError:
            # Compatibility with an older Plotly Python schema. Newer Plotly
            # versions support textfont.weight and textfont.style directly.
            trace_arguments['textfont'] = base_text_font
            if font_bold or font_italic:
                percentage_template = '%{percent}'
                if font_italic:
                    percentage_template = f'<i>{percentage_template}</i>'
                if font_bold:
                    percentage_template = f'<b>{percentage_template}</b>'
                trace_arguments['texttemplate'] = percentage_template

            try:
                return [graph_objs.Pie(**trace_arguments)]
            except ValueError:
                # Very old Plotly versions may not support texttemplate either.
                trace_arguments.pop('texttemplate', None)
                return [graph_objs.Pie(**trace_arguments)]

    @staticmethod
    def create_layout(settings):
        layout = super(PieChartFactory, PieChartFactory).create_layout(settings)

        layout['xaxis'].update(title='')
        layout['xaxis'].update(showgrid=False)
        layout['xaxis'].update(zeroline=False)
        layout['xaxis'].update(showline=False)
        layout['xaxis'].update(showticklabels=False)
        layout['yaxis'].update(title='')
        layout['yaxis'].update(showgrid=False)
        layout['yaxis'].update(zeroline=False)
        layout['yaxis'].update(showline=False)
        layout['yaxis'].update(showticklabels=False)

        return layout
