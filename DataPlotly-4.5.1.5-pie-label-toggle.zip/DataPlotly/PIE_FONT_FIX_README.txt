DataPlotly 4.5.1.5 custom pie label font controls
=================================================

For Pie Chart plots, the Properties section now contains:
- Pie percentage font size
- Pie percentage font (font family selector)
- Pie font style: Show percentage labels, Bold and Italic

Tick "Show percentage labels" to display the text, or untick it to hide the
text. Change the controls and click Update Plot. The values are saved with the
chart configuration.
