# coding=utf-8
"""QGIS Processing provider for Animation Workbench."""

from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon

from ..utilities import resources_path
from .open_workbench_algorithm import OpenAnimationWorkbenchAlgorithm


class AnimationWorkbenchProvider(QgsProcessingProvider):
    """Expose Animation Workbench in the Processing Toolbox."""

    @staticmethod
    def tr(message):
        """Translate provider strings without relying on QObject inheritance."""
        return QCoreApplication.translate("AnimationWorkbenchProvider", message)

    def id(self):
        return "animation_workbench"

    def name(self):
        return self.tr("Animation Workbench")

    def longName(self):
        return self.name()

    def icon(self):
        return QIcon(resources_path("icons", "icon.png"))

    def loadAlgorithms(self):
        self.addAlgorithm(OpenAnimationWorkbenchAlgorithm())
