# coding=utf-8
"""Processing Toolbox launcher for Animation Workbench."""

import qgis.utils as qgis_utils
from qgis.core import Qgis, QgsProcessingAlgorithm, QgsProcessingException
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon

from ..utilities import resources_path


class OpenAnimationWorkbenchAlgorithm(QgsProcessingAlgorithm):
    """Open the interactive Animation Workbench dialog from Processing."""

    @staticmethod
    def tr(message):
        """Translate Processing strings without relying on QObject inheritance."""
        return QCoreApplication.translate("OpenAnimationWorkbenchAlgorithm", message)

    def name(self):
        return "open_animation_workbench"

    def displayName(self):
        return self.tr("Open Animation Workbench")

    def group(self):
        return self.tr("Animation Workbench")

    def groupId(self):
        return "animation_workbench"

    def icon(self):
        return QIcon(resources_path("icons", "icon.png"))

    def tags(self):
        return ["animation", "video", "movie", "gif", "map", "workbench"]

    def shortHelpString(self):
        return self.tr(
            "Opens the interactive Animation Workbench dialog. Use the dialog "
            "to choose an animation layer, configure movement and easing, add "
            "intro/outro media or sound, and export an MP4 or animated GIF."
        )

    def initAlgorithm(self, config=None):
        # This is a GUI launcher and therefore has no Processing parameters.
        del config

    def createInstance(self):
        return OpenAnimationWorkbenchAlgorithm()

    def flags(self):
        # Opening a Qt dialog must happen in QGIS' main GUI thread. The launcher
        # is intentionally hidden from Model Designer because it is interactive.
        processing_flag_enum = getattr(Qgis, "ProcessingAlgorithmFlag", None)
        if processing_flag_enum is not None:
            return processing_flag_enum.NoThreading | processing_flag_enum.HideFromModeler
        return (
            QgsProcessingAlgorithm.FlagNoThreading
            | QgsProcessingAlgorithm.FlagHideFromModeler
        )

    def processAlgorithm(self, parameters, context, feedback):
        del parameters, context
        plugin = qgis_utils.plugins.get("animation_workbench")
        if plugin is None or not hasattr(plugin, "run"):
            raise QgsProcessingException(
                self.tr("Animation Workbench is not loaded. Enable the plugin and try again.")
            )

        plugin.run()
        feedback.pushInfo(self.tr("Animation Workbench opened."))
        return {}
