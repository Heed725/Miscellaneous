# coding=utf-8
"""Processing provider for Animation Workbench."""

from .provider import AnimationWorkbenchProvider

__all__ = ["AnimationWorkbenchProvider"]
