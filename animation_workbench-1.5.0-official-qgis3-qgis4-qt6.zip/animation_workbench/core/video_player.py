# coding=utf-8
"""Qt 5/Qt 6 compatible video player utilities for Animation Workbench."""

__copyright__ = "Copyright 2022, Tim Sutton"
__license__ = "GPL version 3"
__email__ = "tim@kartoza.com"
__revision__ = "$Format:%H$"

import os
import platform
import subprocess
from typing import Optional, Tuple

from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QDesktopServices

QAudioOutput = None
QMediaContent = None
QMediaPlayer = None
QVideoWidget = None
_multimedia_available = False
_multimedia_error = None

try:
    # Always import through QGIS' compatibility namespace. QGIS 3 maps this to
    # PyQt5, while QGIS 4 maps it to PyQt6.
    from qgis.PyQt.QtMultimedia import QMediaPlayer
    try:
        from qgis.PyQt.QtMultimedia import QMediaContent
    except ImportError:
        # QMediaContent was removed in Qt 6. QMediaPlayer.setSource() is used.
        QMediaContent = None
    try:
        from qgis.PyQt.QtMultimedia import QAudioOutput
    except ImportError:
        QAudioOutput = None
    from qgis.PyQt.QtMultimediaWidgets import QVideoWidget

    _multimedia_available = True
except (ImportError, AttributeError) as error:
    _multimedia_error = str(error)


def is_multimedia_available() -> Tuple[bool, Optional[str]]:
    """Return whether an embedded Qt multimedia player is available."""
    return _multimedia_available, _multimedia_error


def create_media_player(parent=None):
    """Create a QMediaPlayer and optional Qt 6 audio output.

    Qt 5 can use the VideoSurface flag, while Qt 6 removed that constructor
    flag. The fallbacks keep the same plugin package usable on both versions.
    """
    if not _multimedia_available or QMediaPlayer is None:
        return None, None

    player = None
    flag_enum = getattr(QMediaPlayer, "Flag", None)
    if flag_enum is not None and hasattr(flag_enum, "VideoSurface"):
        try:
            player = QMediaPlayer(parent, flag_enum.VideoSurface)
        except TypeError:
            player = None
    elif hasattr(QMediaPlayer, "VideoSurface"):
        try:
            player = QMediaPlayer(parent, QMediaPlayer.VideoSurface)
        except TypeError:
            player = None

    if player is None:
        player = QMediaPlayer(parent)

    audio_output = None
    if QAudioOutput is not None and hasattr(player, "setAudioOutput"):
        try:
            audio_output = QAudioOutput(parent)
            player.setAudioOutput(audio_output)
        except (TypeError, RuntimeError):
            audio_output = None

    return player, audio_output


def set_media_file(player, file_path: str) -> None:
    """Load a local media file using the Qt 5 or Qt 6 player API."""
    url = QUrl.fromLocalFile(file_path)
    if hasattr(player, "setSource"):
        player.setSource(url)
    elif QMediaContent is not None:
        player.setMedia(QMediaContent(url))
    else:
        raise RuntimeError("No supported Qt multimedia source API is available")


def media_player_is_playing(player) -> bool:
    """Return whether a Qt 5 or Qt 6 media player is currently playing."""
    if hasattr(player, "playbackState"):
        state = player.playbackState()
        playback_enum = getattr(QMediaPlayer, "PlaybackState", None)
        return playback_enum is not None and state == playback_enum.PlayingState

    state = player.state()
    state_enum = getattr(QMediaPlayer, "State", None)
    if state_enum is not None:
        return state == state_enum.PlayingState
    return state == QMediaPlayer.PlayingState


def connect_player_state_signal(player, slot) -> None:
    """Connect the playback-state signal available in the current Qt version."""
    signal = getattr(player, "playbackStateChanged", None)
    if signal is None:
        signal = player.stateChanged
    signal.connect(slot)


def connect_player_error_signal(player, slot) -> None:
    """Connect the multimedia error signal available in the current Qt version."""
    signal = getattr(player, "errorOccurred", None)
    if signal is None:
        signal = player.error
    signal.connect(slot)


def open_in_system_player(file_path: str) -> Tuple[bool, Optional[str]]:
    """Open a video file in the operating system's default media player."""
    if not os.path.exists(file_path):
        return False, f"File not found: {file_path}"

    system = platform.system()
    try:
        url = QUrl.fromLocalFile(file_path)
        if QDesktopServices.openUrl(url):
            return True, None

        if system == "Windows":
            os.startfile(file_path)  # noqa: S606
        elif system == "Darwin":
            subprocess.run(["open", file_path], check=True)  # noqa: S603,S607
        else:
            try:
                subprocess.run(["xdg-open", file_path], check=True)  # noqa: S603,S607
            except (subprocess.CalledProcessError, FileNotFoundError):
                subprocess.run(["gio", "open", file_path], check=True)  # noqa: S603,S607
        return True, None
    except (OSError, subprocess.SubprocessError) as error:
        return False, str(error)


def get_system_player_name() -> str:
    """Return a user-facing name for the platform's default media player."""
    system = platform.system()
    if system == "Windows":
        return "the Windows default media player"
    if system == "Darwin":
        return "the macOS default media player"
    return "the system default media player"


def get_video_playback_instructions() -> str:
    """Return fallback help shown when Qt Multimedia is unavailable."""
    details = f"<p><b>Embedded video preview is unavailable.</b></p><p>Use <b>Open External</b> to view the finished animation in {get_system_player_name()}.</p>"
    if _multimedia_error:
        details += f"<p><small>Qt Multimedia detail: {_multimedia_error}</small></p>"
    return details
