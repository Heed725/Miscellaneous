# coding=utf-8
"""Easing selector and preview widget for AnimationWorkbench.

The preview is rendered with Qt's native QPainter API so the plugin does not
require the third-party ``pyqtgraph`` package.
"""

__copyright__ = "Copyright 2022, Tim Sutton"
__license__ = "GPL version 3"
__email__ = "tim@kartoza.com"
__revision__ = "$Format:%H$"

from qgis.PyQt.QtCore import QEasingCurve, QPointF, QSize, Qt, QTimer, pyqtSignal
from qgis.PyQt.QtGui import QColor, QPainter, QPainterPath, QPalette, QPen
from qgis.PyQt.QtWidgets import QApplication, QVBoxLayout, QWidget

from .utilities import get_ui_class

# Kartoza Brand Colors
KARTOZA_GREEN_DARK = "#589632"
KARTOZA_GREEN_LIGHT = "#93b023"

# Theme-specific colors
DARK_THEME = {
    "background": "#2d2d2d",
    "foreground": KARTOZA_GREEN_LIGHT,
    "dot_color": "#ff6b6b",
    "border": KARTOZA_GREEN_DARK,
}

LIGHT_THEME = {
    "background": "#f5f5f5",
    "foreground": KARTOZA_GREEN_DARK,
    "dot_color": "#e74c3c",
    "border": KARTOZA_GREEN_DARK,
}

# Animation settings
ANIMATION_DURATION_MS = 3000
ANIMATION_STEPS = 100
DOT_SIZE = 12
CURVE_SAMPLES = 240

FORM_CLASS = get_ui_class("easing_preview_base.ui")


class EasingCurveCanvas(QWidget):
    """Small dependency-free canvas used to draw an easing curve."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._easing = QEasingCurve(QEasingCurve.Type.Linear)
        self._progress = 0.0
        self._background = QColor(LIGHT_THEME["background"])
        self._foreground = QColor(LIGHT_THEME["foreground"])
        self._dot_color = QColor(LIGHT_THEME["dot_color"])
        self._border = QColor(LIGHT_THEME["border"])
        self.setMinimumSize(150, 80)

    def sizeHint(self):  # pylint: disable=invalid-name
        """Return a compact but readable default canvas size."""
        return QSize(260, 100)

    def set_theme(self, theme: dict):
        """Apply preview colors and repaint."""
        self._background = QColor(theme["background"])
        self._foreground = QColor(theme["foreground"])
        self._border = QColor(theme["border"])
        if not self._dot_color.isValid():
            self._dot_color = QColor(theme["dot_color"])
        self.update()

    def set_easing(self, easing: QEasingCurve):
        """Set the easing curve displayed by the canvas."""
        self._easing = QEasingCurve(easing)
        self.update()

    def set_progress(self, progress: float):
        """Move the animated indicator to a normalized progress value."""
        self._progress = max(0.0, min(1.0, float(progress)))
        self.update()

    def set_dot_color(self, color):
        """Set the indicator dot color when ``color`` is QColor-compatible."""
        try:
            parsed = QColor(color)
        except (TypeError, ValueError):
            return
        if parsed.isValid():
            self._dot_color = parsed
            self.update()

    def _curve_points(self):
        """Return sampled curve values and their min/max range."""
        samples = []
        for i in range(CURVE_SAMPLES):
            x = i / (CURVE_SAMPLES - 1)
            samples.append((x, self._easing.valueForProgress(x)))

        values = [value for _, value in samples]
        minimum = min(0.0, min(values))
        maximum = max(1.0, max(values))
        if abs(maximum - minimum) < 1e-9:
            maximum = minimum + 1.0
        return samples, minimum, maximum

    def paintEvent(self, event):  # pylint: disable=invalid-name,unused-argument
        """Paint the chart, curve, and animated indicator."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        outer = self.rect().adjusted(2, 2, -2, -2)
        painter.setPen(QPen(self._border, 2))
        painter.setBrush(self._background)
        painter.drawRoundedRect(outer, 6, 6)

        plot = outer.adjusted(10, 8, -10, -8)
        if plot.width() <= 1 or plot.height() <= 1:
            return

        samples, minimum, maximum = self._curve_points()
        value_range = maximum - minimum

        def map_point(x_value, y_value):
            x = plot.left() + x_value * plot.width()
            normalized_y = (y_value - minimum) / value_range
            y = plot.bottom() - normalized_y * plot.height()
            return QPointF(x, y)

        path = QPainterPath()
        first_x, first_y = samples[0]
        path.moveTo(map_point(first_x, first_y))
        for x_value, y_value in samples[1:]:
            path.lineTo(map_point(x_value, y_value))

        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(self._foreground, 3))
        painter.drawPath(path)

        dot_y = self._easing.valueForProgress(self._progress)
        dot = map_point(self._progress, dot_y)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(self._dot_color)
        radius = DOT_SIZE / 2.0
        painter.drawEllipse(dot, radius, radius)


class EasingPreview(QWidget, FORM_CLASS):
    """Widget for selecting an easing mode and previewing its curve."""

    easing_changed_signal = pyqtSignal(QEasingCurve)

    def __init__(self, color=None, parent=None):
        # Qt's UI loader constructs promoted widgets as ``EasingPreview(parent)``.
        # The upstream class historically used ``color`` as its first argument,
        # so a QFrame parent was accidentally interpreted as a QColor value.
        # Preserve the old color-first API while correctly accepting Qt parents.
        if isinstance(color, QWidget) and parent is None:
            parent = color
            color = None

        QWidget.__init__(self, parent)
        self.setupUi(self)

        self.easing = QEasingCurve(QEasingCurve.Type.Linear)
        self.animation_progress = 0.0
        self.animation_direction = 1
        self._animation_running = False
        self._animation_interval = ANIMATION_DURATION_MS // ANIMATION_STEPS

        # The UI contains a plain QWidget placeholder. Put the native canvas
        # inside it at runtime, avoiding a pyqtgraph promoted-widget import.
        chart_layout = QVBoxLayout(self.chart)
        chart_layout.setContentsMargins(0, 0, 0, 0)
        chart_layout.setSpacing(0)
        self.chart_canvas = EasingCurveCanvas(self.chart)
        chart_layout.addWidget(self.chart_canvas)

        if color:
            self.chart_canvas.set_dot_color(color)

        self.animation_timer = QTimer(self)
        self.animation_timer.setSingleShot(True)
        self.animation_timer.timeout.connect(self._update_animation)

        self.load_combo_with_easings()
        self.setup_chart()
        self.easing_combo.currentIndexChanged.connect(self.easing_changed)
        self.enable_easing.toggled.connect(self.checkbox_changed)

    def is_dark_theme(self) -> bool:
        """Return whether the current application palette is dark."""
        app = QApplication.instance()
        if app is None:
            return False
        window_color = app.palette().color(QPalette.ColorRole.Window)
        luminance = 0.299 * window_color.red() + 0.587 * window_color.green() + 0.114 * window_color.blue()
        return luminance < 128

    def get_theme(self) -> dict:
        """Get colors suitable for the current QGIS theme."""
        return DARK_THEME if self.is_dark_theme() else LIGHT_THEME

    def setup_chart(self):
        """Initialize the native easing preview canvas."""
        self.chart_canvas.set_theme(self.get_theme())
        self.chart_canvas.set_easing(self.easing)
        self.chart_canvas.set_progress(self.animation_progress)
        self._animation_running = True
        self.animation_timer.start(self._animation_interval)

    def _update_animation(self):
        """Update the animation progress and dot position."""
        try:
            step = 1.0 / ANIMATION_STEPS
            self.animation_progress += step * self.animation_direction

            if self.animation_progress >= 1.0:
                self.animation_progress = 1.0
                self.animation_direction = -1
            elif self.animation_progress <= 0.0:
                self.animation_progress = 0.0
                self.animation_direction = 1

            self._update_dot_position()
        finally:
            if self._animation_running:
                self.animation_timer.start(self._animation_interval)

    def set_progress(self, progress: float):
        """Set the dot position using a value from 0.0 to 1.0."""
        self.animation_progress = max(0.0, min(1.0, float(progress)))
        self._update_dot_position()

    def _update_dot_position(self):
        """Update the indicator on the native preview canvas."""
        self.chart_canvas.set_progress(self.animation_progress)

    def checkbox_changed(self, new_state):
        """Start or stop animation when easing is toggled."""
        if new_state:
            self.enable()
        else:
            self.disable()

    def disable(self):
        """Disable easing and stop the preview timer."""
        self.enable_easing.setChecked(False)
        self._animation_running = False
        self.animation_timer.stop()

    def enable(self):
        """Enable easing and start the preview timer."""
        self.enable_easing.setChecked(True)
        self._animation_running = True
        if not self.animation_timer.isActive():
            self.animation_timer.start(self._animation_interval)

    def is_enabled(self) -> bool:
        """Return whether easing is enabled."""
        return self.enable_easing.isChecked()

    def set_easing_by_name(self, name: str):
        """Select an easing mode by its displayed name."""
        index = self.easing_combo.findText(name)
        if index != -1:
            self.easing_combo.setCurrentIndex(index)

    def easing_name(self) -> str:
        """Return the selected easing mode name."""
        return self.easing_combo.currentText()

    def get_easing(self):
        """Return the selected QEasingCurve."""
        easing_type = self.easing_combo.currentData()
        return QEasingCurve(easing_type)

    def set_preview_color(self, color: str):
        """Set the indicator dot color."""
        self.chart_canvas.set_dot_color(color)

    def set_checkbox_label(self, label: str):
        """Set the text displayed beside the enable checkbox."""
        self.enable_easing.setText(label)

    def load_combo_with_easings(self):
        """Populate the combobox with available Qt easing modes."""
        combo = self.easing_combo
        combo.addItem("Linear", QEasingCurve.Type.Linear)
        combo.addItem("InQuad", QEasingCurve.Type.InQuad)
        combo.addItem("OutQuad", QEasingCurve.Type.OutQuad)
        combo.addItem("InOutQuad", QEasingCurve.Type.InOutQuad)
        combo.addItem("OutInQuad", QEasingCurve.Type.OutInQuad)
        combo.addItem("InCubic", QEasingCurve.Type.InCubic)
        combo.addItem("OutCubic", QEasingCurve.Type.OutCubic)
        combo.addItem("InOutCubic", QEasingCurve.Type.InOutCubic)
        combo.addItem("OutInCubic", QEasingCurve.Type.OutInCubic)
        combo.addItem("InQuart", QEasingCurve.Type.InQuart)
        combo.addItem("OutQuart", QEasingCurve.Type.OutQuart)
        combo.addItem("InOutQuart", QEasingCurve.Type.InOutQuart)
        combo.addItem("OutInQuart", QEasingCurve.Type.OutInQuart)
        combo.addItem("InQuint", QEasingCurve.Type.InQuint)
        combo.addItem("OutQuint", QEasingCurve.Type.OutQuint)
        combo.addItem("InOutQuint", QEasingCurve.Type.InOutQuint)
        combo.addItem("OutInQuint", QEasingCurve.Type.OutInQuint)
        combo.addItem("InSine", QEasingCurve.Type.InSine)
        combo.addItem("OutSine", QEasingCurve.Type.OutSine)
        combo.addItem("InOutSine", QEasingCurve.Type.InOutSine)
        combo.addItem("OutInSine", QEasingCurve.Type.OutInSine)
        combo.addItem("InExpo", QEasingCurve.Type.InExpo)
        combo.addItem("OutExpo", QEasingCurve.Type.OutExpo)
        combo.addItem("InOutExpo", QEasingCurve.Type.InOutExpo)
        combo.addItem("OutInExpo", QEasingCurve.Type.OutInExpo)
        combo.addItem("InCirc", QEasingCurve.Type.InCirc)
        combo.addItem("OutCirc", QEasingCurve.Type.OutCirc)
        combo.addItem("InOutCirc", QEasingCurve.Type.InOutCirc)
        combo.addItem("OutInCirc", QEasingCurve.Type.OutInCirc)
        combo.addItem("InElastic", QEasingCurve.Type.InElastic)
        combo.addItem("OutElastic", QEasingCurve.Type.OutElastic)
        combo.addItem("InOutElastic", QEasingCurve.Type.InOutElastic)
        combo.addItem("OutInElastic", QEasingCurve.Type.OutInElastic)
        combo.addItem("InBack", QEasingCurve.Type.InBack)
        combo.addItem("OutBack", QEasingCurve.Type.OutBack)
        combo.addItem("InOutBack", QEasingCurve.Type.InOutBack)
        combo.addItem("OutInBack", QEasingCurve.Type.OutInBack)
        combo.addItem("InBounce", QEasingCurve.Type.InBounce)
        combo.addItem("OutBounce", QEasingCurve.Type.OutBounce)
        combo.addItem("InOutBounce", QEasingCurve.Type.InOutBounce)
        combo.addItem("OutInBounce", QEasingCurve.Type.OutInBounce)
        combo.addItem("BezierSpline", QEasingCurve.Type.BezierSpline)
        combo.addItem("TCBSpline", QEasingCurve.Type.TCBSpline)

    def easing_changed(self, index):
        """Update the preview when a different easing mode is selected."""
        easing_type = self.easing_combo.itemData(index)
        self.easing = QEasingCurve(easing_type)
        self.easing_changed_signal.emit(self.easing)
        self.chart_canvas.set_easing(self.easing)
        self._update_dot_position()
